/**
 * @private
 */
Ext.define('Ext.device.splashscreen.Abstract', {
    show: Ext.emptyFn,
    hide: Ext.emptyFn
});