/**
 * @private
 */
Ext.define('Ext.device.storage.Cordova', {
    alternateClassName: 'Ext.device.storage.PhoneGap',

    extend: 'Ext.device.storage.HTML5.HTML5'
});
