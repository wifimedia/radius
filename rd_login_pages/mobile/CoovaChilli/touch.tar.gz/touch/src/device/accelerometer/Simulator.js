/**
 * @private
 */
Ext.define('Ext.device.accelerometer.Simulator', {
    extend: 'Ext.device.accelerometer.Abstract'
});
