/**
 * @private
 */
Ext.define('Ext.device.compass.Simulator', {
    extend: 'Ext.device.compass.Abstract'
});
