# theme-device-base/sass/etc

This folder contains miscellaneous SASS files. Unlike `"theme-device-base/sass/etc"`, these files
need to be used explicitly.
