Ext.define('Ext.field.trigger.Search', {
    extend: 'Ext.field.trigger.Trigger',
    xtype: 'searchtrigger',
    alias: 'trigger.search',
    classCls: Ext.baseCSSPrefix + 'searchtrigger'
});
