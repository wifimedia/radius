Ext.define('Ext.theme.material.panel.Header', {
    override: 'Ext.panel.Header',

    config: {
        titleAlign: 'left'
    }
});
