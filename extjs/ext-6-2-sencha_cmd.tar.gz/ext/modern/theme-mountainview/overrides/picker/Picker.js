Ext.define('Ext.theme.mountainview.picker.Picker', {
    override: 'Ext.picker.Picker',

    config: {
        toolbarPosition: 'bottom',
        toolbar: {
            defaults: {
                flex: 1
            }
        }
    }
});