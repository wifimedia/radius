Ext.namespace('Ext.theme.is').Neptune = true;
Ext.theme.name = 'Neptune';

Ext.theme.getDocCls = function() {
    return Ext.platformTags.desktop ? '' : 'x-big';
};
