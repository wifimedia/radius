Ext.define('Ext.theme.ios.field.Checkbox', {
    override: 'Ext.field.Checkbox',
    config: {
        bodyAlign: 'end'
    }
});