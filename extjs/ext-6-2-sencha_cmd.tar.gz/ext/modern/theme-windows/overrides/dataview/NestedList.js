Ext.define('Ext.theme.windows.dataview.NestedList', {
    override: 'Ext.dataview.NestedList',

    config: {
        itemHeight: 42
    }
});