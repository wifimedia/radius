# theme-windows/sass/etc

This folder contains miscellaneous SASS files. Unlike `"theme-windows/sass/etc"`, these files
need to be used explicitly.
