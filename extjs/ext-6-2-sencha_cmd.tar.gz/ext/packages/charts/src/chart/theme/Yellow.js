Ext.define('Ext.chart.theme.Yellow', {
    extend: 'Ext.chart.theme.Base',
    singleton: true,
    alias: [
        'chart.theme.yellow',
        'chart.theme.Yellow'
    ],
    config: {
        baseColor: '#fec935'
    }
});