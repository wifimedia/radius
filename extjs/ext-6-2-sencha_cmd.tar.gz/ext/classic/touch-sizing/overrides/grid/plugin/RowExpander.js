Ext.define('Ext.theme.touchsizing.grid.plugin.RowExpander', {
    override: 'Ext.grid.plugin.RowExpander',
    
    headerWidth: 32
});