Ext.define('Ext.theme.classic.grid.plugin.Editing', {
    override: 'Ext.grid.plugin.Editing',

    defaultFieldUI: 'grid-cell'
});